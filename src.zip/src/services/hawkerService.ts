import { query } from '../db.js';
import { getSingaporeToday } from '../lib/date.js';
import { ActiveClosureRow, HawkerCentreRow, HawkerListItem, HawkerStatus } from '../types.js';

function distanceSql(latParamIndex: number, lngParamIndex: number): string {
  return `
    (
      6371 * acos(
        LEAST(
          1,
          cos(radians($${latParamIndex})) * cos(radians(latitude)) *
          cos(radians(longitude) - radians($${lngParamIndex})) +
          sin(radians($${latParamIndex})) * sin(radians(latitude))
        )
      )
    )
  `;
}

function statusFromEventType(eventType: ActiveClosureRow['event_type']): HawkerStatus {
  if (eventType === 'cleaning') return 'closed_cleaning';
  if (eventType === 'rr') return 'closed_rr';
  return 'closed_other_works';
}

async function getActiveClosures(hawkerIds: string[], date: string): Promise<Map<string, ActiveClosureRow>> {
  if (hawkerIds.length === 0) return new Map();

  const result = await query<ActiveClosureRow>(
    `
      SELECT DISTINCT ON (hawker_centre_id)
        hawker_centre_id,
        event_type,
        title,
        start_date::text,
        end_date::text,
        remarks,
        source_quarter
      FROM closure_events
      WHERE hawker_centre_id = ANY($1::uuid[])
        AND $2::date BETWEEN start_date AND end_date
      ORDER BY
        hawker_centre_id,
        CASE event_type
          WHEN 'rr' THEN 1
          WHEN 'other_works' THEN 2
          WHEN 'cleaning' THEN 3
          ELSE 4
        END
    `,
    [hawkerIds, date]
  );

  return new Map(result.rows.map((row) => [row.hawker_centre_id, row]));
}

function mergeWithStatus(hawkers: Array<HawkerCentreRow & { distance_km?: number | null }>, closures: Map<string, ActiveClosureRow>): HawkerListItem[] {
  return hawkers.map((hawker) => {
    const active = closures.get(hawker.id) ?? null;
    return {
      ...hawker,
      distance_km: hawker.distance_km ?? null,
      status: active ? statusFromEventType(active.event_type) : 'open',
      active_closure: active,
    };
  });
}

export async function getNearbyHawkers(input: { lat: number; lng: number; radiusKm?: number; limit?: number; date?: string; }): Promise<HawkerListItem[]> {
  const radiusKm = input.radiusKm ?? 5;
  const limit = input.limit ?? 20;
  const date = input.date ?? getSingaporeToday();
  const distExpr = distanceSql(1, 2);

  const result = await query<HawkerCentreRow & { distance_km: number }>(
    `
      SELECT id, slug, name, address, latitude, longitude, photo_url, description, no_market_stalls, no_food_stalls, source_status,
        ${distExpr} AS distance_km
      FROM hawker_centres
      WHERE ${distExpr} <= $3
      ORDER BY distance_km ASC, name ASC
      LIMIT $4
    `,
    [input.lat, input.lng, radiusKm, limit]
  );

  const closures = await getActiveClosures(result.rows.map((row) => row.id), date);
  return mergeWithStatus(result.rows, closures);
}

export async function searchHawkers(input: { queryText: string; lat?: number; lng?: number; limit?: number; date?: string; }): Promise<HawkerListItem[]> {
  const limit = input.limit ?? 20;
  const date = input.date ?? getSingaporeToday();

  let sql = `
    SELECT id, slug, name, address, latitude, longitude, photo_url, description, no_market_stalls, no_food_stalls, source_status,
      NULL::double precision AS distance_km
    FROM hawker_centres
    WHERE name ILIKE $1 OR address ILIKE $1
    ORDER BY name ASC
    LIMIT $2
  `;
  let params: any[] = [`%${input.queryText}%`, limit];

  if (typeof input.lat === 'number' && typeof input.lng === 'number') {
    const distExpr = distanceSql(2, 3);
    sql = `
      SELECT id, slug, name, address, latitude, longitude, photo_url, description, no_market_stalls, no_food_stalls, source_status,
        ${distExpr} AS distance_km
      FROM hawker_centres
      WHERE name ILIKE $1 OR address ILIKE $1
      ORDER BY distance_km ASC NULLS LAST, name ASC
      LIMIT $4
    `;
    params = [`%${input.queryText}%`, input.lat, input.lng, limit];
  }

  const result = await query<HawkerCentreRow & { distance_km: number | null }>(sql, params);
  const closures = await getActiveClosures(result.rows.map((row) => row.id), date);
  return mergeWithStatus(result.rows, closures);
}

export async function getHawkerDetail(id: string, date?: string): Promise<HawkerListItem | null> {
  const targetDate = date ?? getSingaporeToday();
  const result = await query<HawkerCentreRow>(
    `
      SELECT id, slug, name, address, latitude, longitude, photo_url, description, no_market_stalls, no_food_stalls, source_status
      FROM hawker_centres
      WHERE id = $1
      LIMIT 1
    `,
    [id]
  );

  const hawker = result.rows[0];
  if (!hawker) return null;

  const closures = await getActiveClosures([id], targetDate);
  return mergeWithStatus([hawker], closures)[0];
}

export async function getAlternatives(input: { hawkerId: string; lat: number; lng: number; radiusKm?: number; limit?: number; date?: string; }): Promise<HawkerListItem[]> {
  const radiusKm = input.radiusKm ?? 3;
  const limit = input.limit ?? 5;
  const date = input.date ?? getSingaporeToday();
  const distExpr = distanceSql(2, 3);

  const result = await query<HawkerCentreRow & { distance_km: number }>(
    `
      SELECT id, slug, name, address, latitude, longitude, photo_url, description, no_market_stalls, no_food_stalls, source_status,
        ${distExpr} AS distance_km
      FROM hawker_centres
      WHERE id <> $1
        AND ${distExpr} <= $4
      ORDER BY distance_km ASC, name ASC
      LIMIT $5
    `,
    [input.hawkerId, input.lat, input.lng, radiusKm, limit * 3]
  );

  const closures = await getActiveClosures(result.rows.map((row) => row.id), date);
  return mergeWithStatus(result.rows, closures).filter((item) => item.status === 'open').slice(0, limit);
}

export async function getUserFavourites(userId: string, date?: string): Promise<HawkerListItem[]> {
  const targetDate = date ?? getSingaporeToday();
  const result = await query<HawkerCentreRow>(
    `
      SELECT h.id, h.slug, h.name, h.address, h.latitude, h.longitude, h.photo_url, h.description, h.no_market_stalls, h.no_food_stalls, h.source_status
      FROM user_favourites f
      INNER JOIN hawker_centres h ON h.id = f.hawker_centre_id
      WHERE f.user_id = $1
      ORDER BY f.created_at DESC
    `,
    [userId]
  );

  const closures = await getActiveClosures(result.rows.map((row) => row.id), targetDate);
  return mergeWithStatus(result.rows, closures);
}
